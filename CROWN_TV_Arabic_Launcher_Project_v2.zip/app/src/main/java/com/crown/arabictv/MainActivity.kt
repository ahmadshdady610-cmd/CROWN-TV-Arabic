package com.crown.arabictv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 18, 31)
    private val accent = Color.rgb(74, 190, 174)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 32, 48, 32)
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "CROWN | الواجهة العربية"
            textSize = 34f
            setTextColor(accent)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "شاشة انتظار ذكية: الساعة، الصلاة، الطقس ومباريات ريال مدريد"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 28)
        }, LinearLayout.LayoutParams(-1, -2))
        val btn = Button(this).apply {
            text = "إعداد شاشة الانتظار"
            textSize = 20f
            setOnClickListener {
                try { startActivity(Intent(Settings.ACTION_DREAM_SETTINGS)) }
                catch (_: Exception) {
                    try { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) } catch (_: Exception) {}
                }
            }
        }
        root.addView(btn, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "بعد التثبيت: افتح إعداد شاشة الانتظار واختر «CROWN TV — شاشة الانتظار العربية» إن ظهر الخيار. قد تختلف أسماء القوائم حسب التلفاز."
            textSize = 17f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }
}
